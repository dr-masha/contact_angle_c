#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <glib.h>

#include "config.h"
#include "gts.h"
#include "intersect_surf.h"
#include "segfl_util.h"
#include "cont_angle.h"
#include "viz_util.h"
#include "mem.h"
  

extern void plot_surface_pack(SurfacePack *,GtsCartesianGrid *,guint32,guint32,
                                                              guint32,gchar *);   
  
// run as './test_sphere d' where d is diameter, odd integer
int main(int argc, char * argv[])
{

 gint    d;
 gint    i, j, k, ind, nxyz, r, r2, dist1;
 gint    sum1, sum2, sum;
 gfloat  r_eff, r_eff2;
 gfloat  xc, yc, zc, h;
 
 gfloat  a, b, c, x0, y0, z0, norm;
 
 gdouble mean;
 		
 GtsCartesianGrid g;
 
 guchar *data1, *data2, *data, *data_sphere;
 
 SurfacePack *pack;
 
 guint32  S1 = 1, S2 = 2, SG = 4;
 
 gchar  fname[256],base[256];
 FILE   *fp;
 
 MEM_START();
 
 d = atoi(argv[1]);
 sprintf(base,"sphere%d",d);
 sprintf(fname,"sphere%d_dist",d); 
 
 /* Initialize grid */
  g.dx = g.dy = g.dz = 1.0; //voxel length assumed 1.0 for now
  g.x = g.y = g.z = -0.5;   //center of the first voxel assumed at (0,0,0)
                            //hence volume boundary starts at (-.5,-.5,-.5)
  g.nx = g.ny = g.nz = d+2;
  
  nxyz = g.nx * g.ny * g.nz;
  data1 = (guchar *)MALLOC(nxyz*UCSZ);
  data2 = (guchar *)MALLOC(nxyz*UCSZ);
  data = (guchar *)MALLOC(nxyz*UCSZ);
  data_sphere = (guchar *)MALLOC(nxyz*UCSZ);
  
  
  /*
  * create digitized data_sphere with diameter 'd'
  * data_sphere == 1 at voxels inside the sphere, otherwise 0
  */
  xc = yc = zc = 0.5*d + 0.5; //ball center
  
  if( (xc - floor(xc)) != 0 ) printf("\nMight have issues with diameter!");
   
  r_eff = 0.5*d; r_eff2 = r_eff*r_eff; //effective ball radius
  r = d/2;  r2 = r*r; //radius that will be used for voxel centers
  ind = 0;
  for(k = 0; k < g.nz; k++) 
    for(j = 0; j < g.ny; j++)
      for(i = 0; i < g.nx; i++, ind++)
      {
          data_sphere[ind] = 0;
	  
	  dist1 = (i - xc)*(i - xc) + (j - yc)*(j - yc) + 
                 (k - zc)*(k - zc);
          if( dist1 < r2 ) data_sphere[ind] = 1;
      }
  
  fp = fopen(fname,"w");
  
  // Define intial plane through (xc,yc,zc)
  //default value
  a = 0; b = 0; c = 1;  //(a,b,c) is plane normal vector
  if(argc == 5)
  {
      a = atof(argv[2]);
      b = atof(argv[3]);
      c = atof(argv[4]);
      printf("\n a %g b %g c %g",a,b,c);
  }
  
  norm = sqrt(a*a + b*b + c*c);
  //normalize
  a = a/norm; b = b/norm; c = c/norm;
  
  //plane moves if normal direction away from sphere center (xc,yc,zc)
  for(h = 0; h < r; h++)
  {
     printf("\nh %g",h); fflush(stdout);
     
     //new plane position
     x0 = xc + h*a;
     y0 = yc + h*b;
     z0 = zc + h*c;
      
     ind = 0;
     sum = sum1 = sum2 = 0;
     for(k = 0; k < g.nz; k++) 
      for(j = 0; j < g.ny; j++)
        for(i = 0; i < g.nx; i++, ind++)
        {
          data[ind] = data1[ind] = data2[ind] = 1;
	  
	 
	  if( a*(i - x0) + b*(j - y0) + c*(k - z0) < 0 ) 
	  {
	     data[ind] = 0; //negative side of the plane is considered grain
	     sum++;
	  }
	  else if(data_sphere[ind] == 1)
	  {
	     data1[ind] = 0;  //fluid 1 is inside sphere and above z-level
	     sum1++;
	  }
	  else
	  {
	     data2[ind] = 0;  //fluid 2 is outside sphere and above z-level
	     sum2++;
	  } 
        }

   if( sum && sum1 && sum2)
   {
     pack = intersect_surfaces_from_data_base(data1,data2,data,&g,S1,S2,SG,
                                	 FALSE,FALSE);
     mean = process_contact_angles(pack,&g,S1,S2,SG,FALSE,FALSE,base,FALSE,0);
     
     //if( h == 10 ) plot_surface_pack(pack,&g,S1,S2,SG,base);
      
     destroy_surface_pack(pack);
     fprintf(fp,"\n%g %g",h/(gfloat)r,mean);
    
   }	
   
   				 
  }
  fclose(fp);
  
  FREE(data); FREE(data1); FREE(data2); 
  FREE(data_sphere);
  FREE(pack);
  
  MEM_STATS();
  
  return 0;
}

