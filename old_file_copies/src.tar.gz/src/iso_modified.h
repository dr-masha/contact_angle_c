#ifndef INCLUDE_ISO_MODIFIED_H
#define INCLUDE_ISO_MODIFIED_H


void gts_isosurface_cartesian_copy (GtsSurface * surfaceG,
			       GtsCartesianGrid g,
			       GtsIsoCartesianFunc f,
			       gpointer data,
			       gdouble iso);				    
				   
#endif
