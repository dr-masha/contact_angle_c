#ifndef included_real_h
#define included_real_h

/* switch for gdouble and gfloat */
#ifndef REAL
 //#define REAL gdouble
 #define REAL gfloat 
#endif

#endif
