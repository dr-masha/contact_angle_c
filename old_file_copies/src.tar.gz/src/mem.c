#include <stdio.h>
#include <glib.h>
#include "mem.h"

/* THis file defines MALLLOC, FREE, CALLOC & REALLOC to be used for consistent
   memory profiling.
   Build on existent Glib memory profiling functions and all it does is making
   them visible to all files in the project.
*/

static GMemVTable	*mem_table;

/* this has to be performed before any other Glib function is used */
void MEM_START(void)
{
     mem_table = glib_mem_profiler_table;
     g_mem_set_vtable (mem_table);
}

void MEM_STATS(void)
{
     g_mem_profile();
}

gpointer MALLOC(gulong	size)
{
        gchar	*new;

	new = (gchar *)mem_table->malloc(size);
	
	return new;
}

gpointer CALLOC(gulong size, gulong size_item)
{
        gchar	*new;

	new = (gchar *)mem_table->calloc(size,size_item);
	
	return new;
}

gpointer REALLOC(
	gpointer ptr,
	gulong	size)
{
        gchar	*new;

	new = (gchar *)mem_table->realloc(ptr,size);
	
	return new;
}

void FREE(gpointer ptr)
{
        mem_table->free(ptr);
}
